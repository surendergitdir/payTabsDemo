<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    function __construct()
    {
        Parent::__construct();
		// $db2 = $this->load->database('db2', TRUE);
    }
    public function insertData($tableName,$data){
		$db2 = $this->load->database('db2', TRUE);
		$db2->insert($tableName,$data);
		$id2 = $db2->insert_id(); 
		if($id2 > 0)
		{
			$this->db->insert($tableName,$data);
			return $this->db->insert_id(); // return both id if required
		}
		else{
			return false;
		}
    }
	public function getSubCategory($p_id){
		$this->db->select(array('parent_category','id','cat_name'))->from('cat_details')->where(array('parent_category'=>$p_id));
		$query = $this->db->get();
		return $query->result_array();
	}
	public function getCategory($p_id){
		$this->db->select(array('parent_category','id','cat_name'))->from('cat_details')->where(array('id'=>$p_id));
		$query = $this->db->get();
		return $query->result_array();
	}
	public function insertSubCat($p_id){
		$catTitle = $this->getCategory($p_id);
		$data = array(
			array(
			   'cat_name' => 'SUB '.$catTitle[0]['cat_name'] ,
			   'parent_category' => $p_id 
			),
			array(
				'cat_name' => 'SUB '.$catTitle[0]['cat_name'] ,
				'parent_category' => $p_id 
			)
		);
		$this->db->insert_batch('cat_details', $data); 
	}
	public function insertMainCat(){
		$data = array(
			array(
			   'cat_name' => 'CATEGORY A' ,
			   'parent_category' => 0
			),
			array(
				'cat_name' => 'CATEGORY B' ,
				'parent_category' => 0 
			)
		);
		$this->db->insert_batch('cat_details', $data); 
	}

}
