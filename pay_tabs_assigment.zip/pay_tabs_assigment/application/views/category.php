<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
    <div class="container">
        <h3>category </h3>
        <div class="form-group">
            <div class="col-md-12">
                <select class="form-control mainCat" >
                    <?php foreach($main_category as $key=>$value){?>
                        <option value="<?=$value['id']?>"><?=$value['cat_name']?></option>
                    <?php } ?>
                </select>    
                <div id="selectSub">
              
                </div>     
                <br/> 
                <input type="btn" name="" value="Add Sub Category" class='btn btn-sm btn-success' id="addCatBtn">
            </div>
            
        </div>          
    </div>
</body>
<script>
    $('#addCatBtn').on('click',function(){
       var mainCat = $(".mainCat").last().val();
       $.ajax({
            type: "POST",
            url: "User/categoryJson",
            data: {catId:mainCat},
            cache: false,
            success: function(html)
            {
                const obj = JSON.parse(html);
                if(obj.success == true){
                    $('#selectSub').append(obj.select);
                }
                else{
                    alert("oops something went wrong");
                }
            },
            error: function (xhr, status) {
                alert("Sorry, there was a problem!");
            },   
        });
    });

</script>

</html>
