<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    function __construct()
    {
        Parent::__construct();
        $this->load->model('User_model','user_model');
    }
	public function index()
	{
        $category['main_category'] = $this->user_model->getSubCategory(0);
		if(count($category['main_category']) == 0){
			$this->user_model->insertMainCat();
			$category['main_category'] = $this->user_model->getSubCategory(0);
			$this->load->view('category',$category);
            
		}
		else{
			$this->load->view('category',$category);
            
		}
	}
	public function categoryJson(){
		$postData = $this->security->xss_clean($this->input->post());
		$checkSubCat = $this->user_model->getSubCategory($postData['catId']);
		if(count($checkSubCat) == 0){
			$this->user_model->insertSubCat($postData['catId']);
			$checkSubCat = $this->user_model->getSubCategory($postData['catId']);
			$response = "<br /><select class='mainCat form-control'>";
			foreach($checkSubCat as $key=>$value){
				$response.="<option value='".$value['id']."'>".$value['cat_name']."</option>";
			}
			$response.="</select>";
			echo json_encode(array("success"=>true,"select"=>$response)); die;
		}
		else{
			$response = "<br /><select class='mainCat form-control'>";
				foreach($checkSubCat as $key=>$value){
					$response.="<option value='".$value['id']."'>".$value['cat_name']."</option>";
				}
			$response.="</select>";
			echo json_encode(array("success"=>true,"select"=>$response)); die;
		}
	}
   
}
